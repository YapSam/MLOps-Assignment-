from flask import Flask,request, url_for, redirect, render_template, jsonify
from pycaret.regression import *
import pandas as pd
import pickle
import numpy as np

import hydra
from hydra import initialize, compose
from omegaconf import OmegaConf

with initialize(version_base=None, config_path="../hydra_config_Abi/"):
    cfg = compose(config_name='main.yaml')
    print(OmegaConf.to_yaml(cfg))

app = Flask(__name__)

model = load_model(cfg.pipeline)
cols = cfg.dcols

@app.route('/')
def home():
    return render_template("HDB_home.html")

@app.route('/predict',methods=['POST'])
def predict():
    int_features = [x for x in request.form.values()]
    final = np.array(int_features)
    data_unseen = pd.DataFrame([final], columns = cols)
    prediction = predict_model(model, data=data_unseen, round = 0)
    prediction = int(prediction.prediction_label[0])
    return render_template('HDB_home.html',pred='Expected Resale Price will be {}'.format(prediction))

@app.route('/predict_api',methods=['POST'])
def predict_api():
    data = request.get_json(force=True)
    data_unseen = pd.DataFrame([data])
    prediction = predict_model(model, data=data_unseen)
    output = prediction.prediction_label[0]
    return jsonify(output)

if __name__ == '__main__':
    app.debug = True
    app.run(host='0.0.0.0', port=5000)
